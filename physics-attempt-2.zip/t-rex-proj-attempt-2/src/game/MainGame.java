package game;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.util.ArrayList;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.paint.Color;



public class MainGame extends Application {
	//game parameters
	ArrayList<Solid> solids;
	ArrayList<Player> players;
	Player target; //player affected by event handlers
	double gravity = 3;
	double walkSpd = 10;
	double jumpSpd = 30;
	double speedCapY = -10; //maximum fall speed
	
	//button press flags
	int direction = 0; //direction for target player
	boolean leftPressed = false;
	boolean rightPressed = false;
	boolean jumpPressed = false;
	
	//display-related parameters
	Timeline tl;
	
	public static void main(String[] args) {
		launch();
	}
	
	@Override
	public void start(Stage primary) {
		solids = new ArrayList<Solid>();
		players = new ArrayList<Player>();
		
		Scene mainScene = mainGameScene();
	
			
		
		primary.setScene(mainScene);
		primary.setTitle("Physics Engine Test");
		primary.show();
		
		
		//timeline-related stuff
		tl = new Timeline();
		tl.setCycleCount(Timeline.INDEFINITE);
		Duration duration = Duration.millis(50); //updates graphics every 50 ms
		EventHandler<ActionEvent> onFrameFinish = new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				
				// TODO Auto-generated method stub
				for(Solid s : solids) {
					updateData(s);
					drawSolid(s);
				}
				
	
			}
			
		};
		KeyFrame keyFrame = new KeyFrame(duration, onFrameFinish);
		tl.getKeyFrames().add(keyFrame);
		tl.play();
	}
	
	//adds an existing player to the list of players and solid objects
	void addPlayer(Player p) {
		players.add(p);
		solids.add(p);
	}
	//creates a new platform and adds it to the list of solid objects
	void addPlatform(double x, double y, double width, double height,Image s) {
		solids.add(new Solid(x,y,width,height,s));
	}
	
	//returns the typical main game scene
	Scene mainGameScene() {
		
		//sets up display
		Group root = new Group();	  
	    
		//creates a default player
	    if (target == null) {
	    	Image imageForPlayer = new Image("t-rex0.png");
	    	ImageView viewForPlayer = new ImageView(imageForPlayer);
	    	viewForPlayer.setX(64);
	    	viewForPlayer.setY(64);
	    	
	    	target = new Player(40,120,imageForPlayer,gravity,walkSpd,jumpSpd,speedCapY);
	    	addPlayer(target);
	    }
	    
	    addPlatform(0,0,480,60,null);
	    addPlatform(0,0,30,480,null);
	    addPlatform(450,0,30,480,null);
	    Scene gameScene = new Scene(root,480,480,Color.WHITE); //initializes scene
		addListener(gameScene);
		attachImageViews(gameScene);
	    return gameScene;
	}
	
	//returns a keylistener
	void addListener(Scene scene) {
		
		//Group listener = new Group();
		scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent key) {
				if (key.getCode() == KeyCode.A) {
					//System.out.println("Pressed left.");
					leftPressed = true;
					direction = -1;
				}
				if (key.getCode() == KeyCode.D) {
					//System.out.println("Pressed right.");
					rightPressed=true;
					direction = 1;
				}
				target.walk(direction);
				if (key.getCode()==KeyCode.W) {
					if (jumpPressed == false) 
					{
						target.jump();
					}
					jumpPressed = true;;
				}
				
			}
			
		});
		
		scene.setOnKeyReleased(new EventHandler<KeyEvent>() {
			@Override
			public void handle(KeyEvent key) {
				
				if (key.getCode() == KeyCode.A) {
					//System.out.println("Pressed left.");
					if (rightPressed) {
						direction = 1;
						}
					else	{
						direction =0;
					}
					leftPressed = false;
					target.walk(direction);
				}
				else if (key.getCode() == KeyCode.D) {
					if (leftPressed) {
						direction = -1;
					}
					else {
						direction = 0;
					}
					rightPressed = false;
						target.walk(direction);
				}
				if (key.getCode() == KeyCode.W) {
					if (jumpPressed)
						jumpPressed = false;
				}
				
				
				}
			
		});

	}
	//draws all solid objects on screen
	void drawSolid(Solid s) {
		//System.out.println("drawing.");
		
		
	}
	
	
	//attaches image views to scene
	void attachImageViews(Scene s) {
		Group root = (Group) s.getRoot();
		for(Solid obj : solids) {
			
			root.getChildren().add(obj.getView());
		}
	}
	
	void updateData(Solid s) {
		//System.out.println("updating data.");
		s.updateCoordinates(solids);
		//s.printData();
	}
}
	
	
	
