package game;

import java.util.ArrayList;

public class BoundingBox {
	double x;
	double y;
	double width;
	double height;
	
	BoundingBox(double x, double y,double width,double height){
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	
	public boolean hasCollision(BoundingBox other) {
		boolean inX = ((other.x >= this.x)&&(other.x <= this.x + width));
		boolean inY = ((other.y >= this.y)&&(other.y <= this.y + height));
		return inX&&inY;
	}
	public boolean isFree(double xCheck, double yCheck, ArrayList<Solid> list) {
		for(Solid s : list) {
			if (s.getCollider() != this) {
				BoundingBox other = s.getCollider();
				boolean xOccupied = (xCheck >= other.x && xCheck < other.x+other.width);
				boolean yOccupied = (yCheck >= other.y && yCheck < other.x+other.height);
				if (xOccupied&&yOccupied) {
					//System.out.println("Collision found");
					return false;
				}
			}
		}
	return true;
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public double getWidth() {
		return width;
	}
	public void setWidth(double width) {
		this.width = width;
	}
	public double getHeight() {
		return height;
	}
	public void setHeight(double height) {
		this.height = height;
	}
	public void setCoordinates(double a, double b) {
		x = a;
		y = b;
	}
	

}
