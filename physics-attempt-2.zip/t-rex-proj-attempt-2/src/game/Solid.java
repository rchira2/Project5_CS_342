package game;

import java.util.ArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Solid {
	double x;
	double y;
	BoundingBox collider;
	Image sprite;
	ImageView spriteView;
	
	double roomHeight=480; //stupid thing i had to add to compensate for backward-ass display
	
	Solid(){
		
	}
	Solid(double x, double y, double width, double height,Image s){
		this.x = x;
		this.y = y;
		collider = new BoundingBox(x,y,width,height);
		sprite = s;
		spriteView = new ImageView(sprite);
	}
	public ImageView getView() {
		return spriteView;
	}
	BoundingBox getCollider() {
		return collider;
	}
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public Image getSprite() {
		return sprite;
	}
	public void setSprite(Image sprite) {
		this.sprite = sprite;
	}
	public void updateCoordinates(ArrayList<Solid> list) {}
	public void printData() {
		//System.out.println("Non-player:\n\t(" + x + ", " + y + ")");
	}
	public void updateImage() {
		//spriteView = new ImageView(sprite);
		spriteView.setX(this.x);
		spriteView.setY(roomHeight-this.y);
		
	}
	public void setRoomHeight(double val) {
		roomHeight = val;
	}
}
