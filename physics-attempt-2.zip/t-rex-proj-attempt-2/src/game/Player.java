package game;

import java.util.ArrayList;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Player extends Solid {
	
	//dynamic values
	
	int score;
	double xVelocity;
	double yVelocity;
	boolean onGround;
	boolean facingRight;
	
	//inherited from game controller using constructor
	double gravity;
	double walkSpd;
	double jumpSpd;
	double speedCapY; //maximum fall speed
	
	
	Player(double x, double y, Image i, double g, double wS, double jS, double spdC){
		this.x = x;
		this.y = y;
		this.sprite = i;
		
		gravity = g;
		walkSpd = wS;
		jumpSpd = jS;
		speedCapY = spdC;
		onGround = false;
		facingRight = true;
		score = 0;
		xVelocity = 0;
		yVelocity = 0;
		
		
		//for displaying sprite
		spriteView = new ImageView(sprite);
		double scaleSize = 3;
		spriteView.setScaleX(scaleSize);
		spriteView.setScaleY(scaleSize);
		
		collider = new BoundingBox(x,y,(double)sprite.getWidth()*scaleSize,(double)sprite.getHeight()*scaleSize);
	}
	void walk(int direction) { //left = -1, right = 1, neutral = 0
		xVelocity = walkSpd*direction;
		
		//changes orientation depending on direction
		if (direction == 1) {
			facingRight = true;
			spriteView.setScaleX(Math.abs(spriteView.getScaleX()));
		}
		else if (direction== -1) {
			facingRight = false;
			spriteView.setScaleX(-Math.abs(spriteView.getScaleX()));
		}
	}
	void jump() {
		if (onGround) { //if on ground, player starts jumping
			yVelocity = jumpSpd;
			onGround = false;
		}
		else { //if not, apply gravity
			if (yVelocity > speedCapY) {
				yVelocity -= gravity;
			}
			
		}
	}
	void updateX(ArrayList<Solid> list) {
		//System.out.println("Updating x");
		int velocitySign = (int) Math.signum(xVelocity);
		//increments x coordinate one by one until hitting an object
		for(int i = 0; i < Math.abs((int)xVelocity); i++) {
				double xCheck = x+velocitySign;
				if (collider.isFree(xCheck, y, list)) {
					x = xCheck;
				}
				else {
					xVelocity = 0;
					return;
				}
				
		}
		
	}
	void updateY(ArrayList<Solid> list) {
		//System.out.println("Updating y");
		if (onGround == true) {
			return;
		}
		else {
			yVelocity = Math.max(speedCapY, yVelocity-gravity);
			int velocitySign = (int) Math.signum(yVelocity);
			//increments x coordinate one by one until hitting an object
			for(int i = 0; i < Math.abs((int)yVelocity); i++) {
					double yCheck = y+velocitySign;
					if (collider.isFree(x, yCheck, list)) {
						y = yCheck;
					}
					else {
						yVelocity = 0;
						onGround = true;
						return;
					}
					
			}
		}
	}
	@Override
	public void updateCoordinates(ArrayList<Solid> list) {
		updateX(list);
		updateY(list);
		updateImage();
		collider.setCoordinates(x,y);
	}
	
	//getters and setters
	public double getX() {
		return x;
	}
	public void setX(double x) {
		this.x = x;
	}
	public double getY() {
		return y;
	}
	public void setY(double y) {
		this.y = y;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public double getxVelocity() {
		return xVelocity;
	}
	public void setxVelocity(double xVelocity) {
		this.xVelocity = xVelocity;
	}
	public double getyVelocity() {
		return yVelocity;
	}
	public void setyVelocity(double yVelocity) {
		this.yVelocity = yVelocity;
	}
	public boolean isOnGround() {
		return onGround;
	}
	public void setOnGround(boolean onGround) {
		this.onGround = onGround;
	}
	public Image getSprite() {
		return sprite;
	}
	public void setSprite(Image sprite) {
		this.sprite = sprite;
	}
	
	
	
	@Override
	public void printData() {
		System.out.println("Player:");
		System.out.println("\tPosition:\t(" + x + "," + y + ")");
		System.out.println("\tVelocity:\t(" + xVelocity + "," + yVelocity + ")");
		System.out.println("\tOn ground:\t" + onGround);
	}
	
	
}
